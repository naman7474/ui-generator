import React from 'https://esm.sh/react@18?dev&target=es2018';
export default function Section2() {
  return React.createElement('div', {
    dangerouslySetInnerHTML: { __html: `<section data-section="GET KILLER DEALS"></section>` }
  });
}
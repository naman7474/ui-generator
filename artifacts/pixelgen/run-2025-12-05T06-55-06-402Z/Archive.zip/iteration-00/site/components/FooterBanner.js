import React from 'https://esm.sh/react@18?dev&target=es2018';
function FooterBanner() {
  return /* @__PURE__ */ React.createElement("section", { "data-section": "Together we are gonna kill it", className: "bg-[#F5F5F5] py-16 text-center px-4" }, /* @__PURE__ */ React.createElement("p", { className: "text-[#D05C35] text-xs font-bold tracking-[0.2em] uppercase mb-4" }, "END OF KILRR CASE FILE"), /* @__PURE__ */ React.createElement("h2", { className: "text-3xl md:text-4xl font-serif text-[#1C1C1C] tracking-wide" }, "TOGETHER WE ARE GONNA KILL IT"));
}
export {
  FooterBanner as default
};
